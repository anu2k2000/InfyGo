package com.infosys.irs.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.irs.payment.entity.CreditCardDetails;

public interface CreditCardRepository extends JpaRepository<CreditCardDetails, String> {
  CreditCardDetails findByCardNumber(String cardNumber);
}
