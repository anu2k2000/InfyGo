/**
 * 
 */
package com.infosys.irs.payment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.irs.payment.entity.CreditCardDetails;
import com.infosys.irs.payment.exception.ARSServiceException;
import com.infosys.irs.payment.repository.CreditCardRepository;;

/**
 * The Class AadharService.
 */
@Service
public class PaymentService {

	@Autowired
	private CreditCardRepository creditCardRepository;

	public boolean validateCreditCard(CreditCardDetails creditCardDetails) throws ARSServiceException {
		CreditCardDetails cardDetails;
		boolean result = false;

		cardDetails = (CreditCardDetails) creditCardRepository.findByCardNumber(creditCardDetails.getCardNumber());

		if (cardDetails != null) {
			result = creditCardDetails.getApin().equals(cardDetails.getApin())
					&& creditCardDetails.getCvv().equals(cardDetails.getCvv())
					&& creditCardDetails.getCardHolderName().equals(cardDetails.getCardHolderName());

		}
		
		return result;
	}

}
